
package com.mbaas.rt.messaging.chat;

public class Defaults
{
  
public static final String APPLICATION_ID = "101C2B27-3F78-0242-FF8B-EEF4B3813100";
public static final String API_KEY = "90CDC719-5CE3-481F-BDB0-652E33ED5043";
public static final String SERVER_URL = "https://api.backendless.com";
    

  public static final String DEFAULT_CHANNEL = "chat";
}
                                            